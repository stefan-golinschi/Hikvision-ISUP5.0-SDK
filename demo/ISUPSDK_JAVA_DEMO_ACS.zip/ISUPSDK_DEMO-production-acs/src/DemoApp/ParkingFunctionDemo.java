package DemoApp;

import java.io.UnsupportedEncodingException;

/**
 * @author zhengxiaohui
 * @date 2023/8/16 18:52
 * @desc 出入口相关的代码实现
 */
public class ParkingFunctionDemo {

    public static void dispatch(String command, int lLoginID) throws UnsupportedEncodingException {
        switch (command) {
            case "20001": {
                // TODO 这里添加出入口相关的代码实现
                break;
            }
        }
    }
}
